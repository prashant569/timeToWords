package com.example.time;

public interface ITimeConverterService {
    public  String convertToWords(String timeStr) ;



}
